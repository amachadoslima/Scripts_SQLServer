USE master 
GO
SET NOCOUNT ON


DECLARE @dte DATETIME
SET @dte = DATEADD(MINUTE, -10, GETDATE())

DECLARE @path NVARCHAR(260) =  '/db/traces/XE_ErrosExec*.xel'

IF(OBJECT_ID(N'tempdb.dbo.#TEMP_XE') IS NOT NULL)
BEGIN
	DROP TABLE #TEMP_XE
END

CREATE TABLE #TEMP_XE
(
	event_name varchar(100),
	package varchar(100),
	utc_timestamp datetime2,
	[error_number] bigint,
	severity int,
	[state] int,
	user_defined varchar(50),
	category varchar(50),
	destination varchar(50),
	linked_server_name varchar(100),
	hresult	varchar(100),
	[message] varchar(max),
	[parameters] varchar(1000),
	username varchar(100),
	session_id int,
	query_plan_hash varchar(50),
	query_hash varchar(50),
	plan_handle varbinary(max),
	[database_name] varchar(100),
	client_hostname varchar(100),
	client_app_name varchar(100)
)

INSERT INTO #TEMP_XE
	SELECT
		n.value('(@name)[1]', 'varchar(100)') as event_name,
		n.value('(@package)[1]', 'varchar(100)') as event_name,
		n.value('(@timestamp)[1]', 'datetime2') AS utc_timestamp,
		n.value('(data[@name="error_number"]/value)[1]', 'bigint') as [error_number],
		n.value('(data[@name="severity"]/value)[1]', 'int') as severity,
		n.value('(data[@name="state"]/value)[1]', 'int') as [state],
		n.value('(data[@name="user_defined"]/value)[1]', 'varchar(50)') as user_defined,
		n.value('(data[@name="category"]/text)[1]', 'varchar(50)') as category,
		n.value('(data[@name="destination"]/text)[1]', 'varchar(50)') as destination,
		n.value('(data[@name="linked_server_name"]/value)[1]', 'varchar(100)') as linked_server_name,
		n.value('(data[@name="hresult"]/value)[1]', 'varchar(100)') as hresult,
		n.value('(data[@name="message"]/value)[1]', 'varchar(max)') as [message],
		n.value('(data[@name="parameters"]/value)[1]', 'varchar(1000)') as [parameters],
		n.value('(action[@name="username"]/value)[1]', 'varchar(100)') as username,
		n.value('(action[@name="session_id"]/value)[1]', 'int') as session_id,
		n.value('(action[@name="query_plan_hash"]/value)[1]', 'varchar(50)') AS query_plan_hash,
		n.value('(action[@name="query_hash"]/value)[1]', 'varchar(50)') AS query_hash,
		CONVERT(VARBINARY(MAX), '0x' + n.value('(action[@name="plan_handle"]/value)[1]', 'varchar(4000)'), 1) AS plan_handle,
		n.value('(action[@name="database_name"]/value)[1]', 'varchar(100)') as [database_name],
		n.value('(action[@name="client_hostname"]/value)[1]', 'varchar(100)') as client_hostname,
		n.value('(action[@name="client_app_name"]/value)[1]', 'varchar(100)') as client_app_name
	FROM(
		SELECT CAST(event_data as XML) as event_data
		FROM sys.fn_xe_file_target_read_file(@path, null, null, null)
	) fx
		CROSS APPLY fx.event_data.nodes('event') as q(n)
	WHERE n.value('(@timestamp)[1]', 'datetime2') >= @dte
	OPTION(MAXDOP 1)

SELECT
	x.event_name,
	x.package,
	x.utc_timestamp,
	DATEADD(HOUR, -3, x.utc_timestamp) as local_timestamp,
	x.[error_number],
	x.severity,
	x.[state],
	x.user_defined,
	x.category,
	x.destination,
	x.linked_server_name,
	x.hresult,
	CASE
		WHEN IsNull(x.[message], '') = '' THEN NULL
		ELSE x.[message]
	END AS [message],
	x.[parameters],
	x.username,
	x.session_id,
	'0x' + x.query_plan_hash AS query_plan_hash,
	'0x' + x.query_hash AS query_hash,
	x.plan_handle,
	p.query_plan,
	x.[database_name],
	x.client_hostname,
	x.client_app_name
FROM #TEMP_XE x
	OUTER APPLY sys.dm_exec_query_plan(x.plan_handle) as p
WHERE x.event_name = 'oledb_error'
--WHERE x.[message] NOT IN
--(
--	'Warning: Null value is eliminated by an aggregate or other SET operation.',
--	'Warning: The join order has been enforced because a local join hint is used.'
--)
ORDER BY 4 DESC
OPTION(MAXDOP 1)