USE dba_adm
GO
;WITH CTE AS
(
	SELECT 
		wait_type,
		MAX(id) AS id,
		MAX(collection_time) AS last_collection_time
	FROM tbWaitStats
	GROUP BY wait_type
)
SELECT TOP 10 T.*
FROM tbWaitStats T
	JOIN CTE C 
		ON T.id = C.id
ORDER BY 4 DESC