USE master 
GO

SET NOCOUNT ON

/*
IF(OBJECT_ID(N'tempdb..#TMP_DTE') IS NULL)
BEGIN
	CREATE TABLE #TMP_DTE
	(
		DTE DATETIME DEFAULT(GETDATE())
	)
	INSERT INTO #TMP_DTE 
		VALUES(DATEADD(HOUR, -12, GETDATE()))
END

DECLARE @dte DATETIME
SELECT @dte = IsNull(DTE, GETDATE()) FROM #TMP_DTE

DECLARE @path VARCHAR(100) =  '/db/traces/XE_Duration_*.xel'

IF(OBJECT_ID(N'tempdb.dbo.#TEMP_XE') IS NOT NULL)
BEGIN
	DROP TABLE #TEMP_XE
END

CREATE TABLE #TEMP_XE
(
	event_name varchar(100),
	utc_timestamp datetime2,
	session_id int,
	client_app_name varchar(200),
	duration bigint,
	cpu bigint,
	physical_reads bigint,
	logical_reads bigint,
	writes bigint,
	row_count bigint,
	last_row_count bigint,
	[database_name] nvarchar(128),
	[sql_text] varchar(max),
	[statement] varchar(max),
	plan_handle varbinary(max)
)

INSERT INTO #TEMP_XE
	SELECT
		n.value('(@name)[1]', 'varchar(100)') as event_name,
		n.value('(@timestamp)[1]', 'datetime2') AS utc_timestamp,
		n.value('(action[@name="session_id"]/value)[1]', 'int') as session_id,
		n.value('(action[@name="client_app_name"]/value)[1]', 'varchar(200)') as client_app_name,
		n.value('(data[@name="duration"]/value)[1]', 'bigint') as duration,
		n.value('(data[@name="cpu_time"]/value)[1]', 'bigint') as cpu,
		n.value('(data[@name="physical_reads"]/value)[1]', 'bigint') as physical_reads,
		n.value('(data[@name="logical_reads"]/value)[1]', 'bigint') as logical_reads,
		n.value('(data[@name="writes"]/value)[1]', 'bigint') as writes,
		n.value('(data[@name="row_count"]/value)[1]', 'bigint') as row_count,
		n.value('(data[@name="last_row_count"]/value)[1]', 'bigint') as last_row_count,
		n.value('(action[@name="database_name"]/value)[1]', 'nvarchar(128)') as [database_name],
		n.value('(action[@name="sql_text"]/value)[1]', 'varchar(max)') as sql_text,
		n.value('(data[@name="statement"]/value)[1]', 'varchar(max)') as [statement],
		CONVERT(VARBINARY(MAX), '0x' + n.value('(action[@name="plan_handle"]/value)[1]', 'varchar(4000)'), 1) AS plan_handle
	FROM(
		SELECT CAST(event_data as XML) as event_data
		FROM sys.fn_xe_file_target_read_file(@path, null, null, null)
	) fx
		CROSS APPLY fx.event_data.nodes('event') as q(n)
	WHERE n.value('(@timestamp)[1]', 'datetime2') >= @dte
*/

--/*
SELECT 
	x.event_name,
	x.utc_timestamp,
	x.session_id,
	x.client_app_name,
	DATEADD(HOUR, -3, x.utc_timestamp) as local_timestamp,
	x.duration,
	FORMAT(DATEADD(MICROSECOND, x.duration, CAST('1900-01-01 00:00:00.000' AS DATETIME2)), 'HH:mm:ss.fff') as duration_time,
	x.cpu,
	x.physical_reads,
	x.logical_reads,
	x.writes,
	x.row_count,
	x.last_row_count,
	x.[database_name],	
	x.sql_text,
	x.[statement],
	x.plan_handle,
	p.query_plan
FROM #TEMP_XE x
	OUTER APPLY sys.dm_exec_query_plan(x.plan_handle) as p
WHERE [statement] LIKE '%sp_recuperar_canais_usuario%'
	--AND [database_name] = 'cronus_sistema_batista'
ORDER BY 7 DESC
--*/

--UPDATE #TMP_DTE SET DTE = GETDATE()