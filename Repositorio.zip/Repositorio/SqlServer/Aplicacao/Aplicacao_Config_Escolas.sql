USE escola_em_movimento
GO
SELECT TOP 10 * 
FROM Cliente 
--WHERE LinkedServer = 'eem_db004'
WHERE Banco = 'eem_colegiovivenciar'
ORDER BY NEWID()