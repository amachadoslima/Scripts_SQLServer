USE cronus_sistema_batista
GO

SET NOCOUNT ON

BEGIN

	DECLARE @p0 INT = 3 
	DECLARE @p1 BIT = 1 
	DECLARE @p10 NVARCHAR(4000) = N'PROFESSOR_TURMA'
	DECLARE @p11 NVARCHAR(4000) = N'COORDENADOR_TURMA'
	DECLARE @p12 NVARCHAR(4000) = N'MEMBRO_GRUPO_USUARIO'
	DECLARE @p13 NVARCHAR(4000) = N'ADMIN_GRUPO_USUARIO'
	DECLARE @p14 NVARCHAR(4000) = N'AUXILIAR_COORDENACAO_TURMA'
	DECLARE @p15 NVARCHAR(4000) = N'DIRETOR'
	DECLARE @p16 NVARCHAR(4000) = N'COLABORADOR'
	DECLARE @p17 NVARCHAR(4000) = N'MOTORISTA_ALUNO'
	DECLARE @p18 NVARCHAR(4000) = N'MOTORISTA_BLOQUEADO_ALUNO'
	DECLARE @p2 NVARCHAR(4000) = NULL
	DECLARE @p3 NVARCHAR(4000) = NULL
	DECLARE @p4 NVARCHAR(4000) = N'ATENDENTE'
	DECLARE @p5 NVARCHAR(4000) = N'ALUNO'
	DECLARE @p6 NVARCHAR(4000) = N'RESPONSAVEL_ALUNO'
	DECLARE @p7 NVARCHAR(4000) = N'USUARIO'
	DECLARE @p8 NVARCHAR(4000) = N'ALUNO'
	DECLARE @p9 NVARCHAR(4000) = N'RESPONSAVEL_ALUNO'

	-- Remove tabelas tempor�rias
	DECLARE @SQL VARCHAR(5000) 
	SELECT 
		@SQL = ISNULL(@SQL+';', '') + 'DROP TABLE ' + SubString(T.[name], 1, CharIndex('___', T.[name])-1) 
	FROM tempdb..sysobjects (NOLOCK) AS T 
	WHERE T.[name] LIKE '#%[_][_][_]%' 
		AND T.Id = Object_ID('tempdb..' + SubString(T.[name], 1, CharIndex('___', T.[name])-1)); 
	
	EXEC (@SQL)
		
	---

	-- Hierarquia (dados v�lidos de acordo com os filtros)
	SELECT 
		Usuario_Id,
		Turma_id,
		Unidade_id,
		Serie_id
	INTO #HierarquiaAcademica
	FROM HierarquiaAcademica
	WHERE (TipoRelacao NOT IN (@p5, @p6) OR TipoRelacao IN (@p7, @p8, @p9, @p10, @p11, @p12, @p13, @p14,@p15,@p16,@p17,@p18)) 

	CREATE NONCLUSTERED INDEX [IX01_#HierarquiaAcademica] ON [dbo].[#HierarquiaAcademica] ([Usuario_Id] ASC) INCLUDE ([Turma_id],[Unidade_id],[Serie_id])
	CREATE NONCLUSTERED INDEX [IX02_#HierarquiaAcademica] ON [dbo].[#HierarquiaAcademica] ([Usuario_Id] ASC)

	-- Usu�rios ativos
	SELECT 
		U.Id
	INTO #PreUsuario
	FROM Usuario U
	WHERE U.Ativo = 1

	SELECT DISTINCT
		U.Id
	INTO #Usuario
	FROM #PreUsuario U
		JOIN #HierarquiaAcademica HA
			ON HA.Usuario_Id = U.Id

	CREATE NONCLUSTERED INDEX [IX_#Usuario] ON #Usuario([Id] ASC)

	SELECT
		u.Id as col_0_0_, 
		t.Id as col_1_0_ 
	INTO #Resultado
	FROM #Usuario U
		JOIN [UsuarioAcessoTurma] UAT 
			ON UAT.Usuario_id = U.Id 
		JOIN [Turma] T 
			ON T.Id = UAT.Turma_id
		JOIN #HierarquiaAcademica HA 
			ON HA.Usuario_id = U.Id 
		JOIN [RelacaoUsuarioTurma] RUT 
			ON RUT.Id = UAT.RelacaoUsuarioTurma_id  
		JOIN [CanalHierarquiaAcademica] AS CHA 
			ON RUT.Id = CHA.RelacaoUsuarioTurma_id
		JOIN [Canal] AS C 
			ON CHA.Canal_id = C.Id
	WHERE CHA.Canal_id = @p0
		AND CHA.TipoPermissao = @p4 
		AND C.Ativo = 1
		--AND (HA.Turma_id IS NULL 
		--	OR (HA.Turma_id = T.Id AND t.Ativo = 1) 
		--	AND (CHA.Turno IS NULL OR T.Turno = cha.Turno)
		--)
		--AND (CHA.Unidade_id IS NULL OR HA.Unidade_id = CHA.Unidade_id)
		--AND (CHA.Serie_id IS NULL OR HA.Serie_id = CHA.Serie_id)
		--AND (CHA.RelacaoUsuarioTurma_id IS NULL 
		--	OR CHA.RelacaoUsuarioTurma_id = RUT.Id
		--)
		OPTION(MAXDOP 1)

END