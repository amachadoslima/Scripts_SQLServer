EXEC dba_adm..stp_growth_tempdb 
	@Days = 2