SELECT 
	sqltext.TEXT,
	req.session_id,
	req.status,
	req.command,
	req.cpu_time,
	req.total_elapsed_time,
	cn.*
FROM sys.dm_exec_requests req
	CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS sqltext 
	LEFT OUTER JOIN sys.dm_exec_sessions AS cn
		ON req.session_id= cn.session_id