DECLARE @spid INT = 175

SELECT 
	t.task_address,
	t.task_state,
	t.pending_io_count,
	t.pending_io_byte_count,
	t.pending_io_byte_average,
	t.scheduler_id,
	t.exec_context_id,
	t.worker_address,
	t.host_address,
	t.parent_task_address,
	th.thread_address,
	th.started_by_sqlservr,
	th.[status],
	th.creation_time,
	th.affinity,
	th.is_waiting_on_loader_lock,
	th.thread_handle,
	th.kernel_time
FROM sys.dm_os_tasks AS t
	INNER JOIN sys.dm_os_threads AS th
		ON t.worker_address = th.worker_address
WHERE t.session_id = @spid
ORDER BY t.session_id


SELECT 
	--r.session_id,
	r.request_id,
	r.start_time,
	r.[status],
	r.command,
	r.[sql_handle],
	r.plan_handle,
	db_name(r.[database_id]) AS [db_name],
	r.blocking_session_id,
	r.wait_type,
	r.open_transaction_count,
	w.worker_address,
	w.[status],
	w.last_wait_type,
	CASE w.return_code
		WHEN 0 THEN 'SUCCESS'
		WHEN 3 THEN 'DEADLOCK'
		WHEN 4 THEN 'PREMATURE_WAKEUP'
		WHEN 258 THEN 'TIMEOUT'
	END AS return_code,
	w.wait_started_ms_ticks,
	w.wait_resumed_ms_ticks,
	w.is_fatal_exception,
	t.os_thread_id,
	r.reads,
	r.writes,
	r.logical_reads
FROM sys.dm_exec_requests AS r
	JOIN sys.dm_os_workers AS w
		ON r.task_address = w.task_address
	JOIN sys.dm_os_threads AS t
		ON t.thread_address = w.thread_address
WHERE session_id = @spid
ORDER BY session_id


DBCC INPUTBUFFER(@SPID)