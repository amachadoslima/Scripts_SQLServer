USE master
GO
BEGIN

	IF(OBJECT_ID(N'tempdb..##TMP_SESSION1') IS NOT NULL)
		DROP TABLE ##TMP_SESSION1

	SELECT 
		COUNT(1) AS [sessions],
         s.[host_name],
         s.host_process_id,
         s.[program_name],
         s.database_id
	INTO ##TMP_SESSION1
	FROM sys.dm_exec_sessions s
	WHERE is_user_process = 1
	GROUP BY 
		[host_name], 
		host_process_id, 
		[program_name], 
		database_id
	--ORDER BY COUNT(1) DESC;

	SELECT 
		DATEDIFF(MINUTE, s.last_request_end_time, GETDATE()) AS minutes_asleep,
		x.[sessions],
		s.session_id,
        DB_NAME(s.database_id) AS [database_name],
		s.[host_name],
        s.host_process_id,
        t.[text] as last_sql,
        s.[program_name]
	FROM sys.dm_exec_connections c
		JOIN sys.dm_exec_sessions s
			ON c.session_id = s.session_id
		CROSS APPLY sys.dm_exec_sql_text(c.most_recent_sql_handle) t
		LEFT JOIN ##TMP_SESSION1 x
			ON x.database_id = s.database_id
				AND s.host_process_id = x.host_process_id
				AND s.[host_name] = x.[host_name]
	WHERE 
		s.is_user_process = 1
        AND s.[status] = 'sleeping'
        AND DATEDIFF(SECOND, s.last_request_end_time, GETDATE()) > 60
		--AND s.session_id = 11477
	GROUP BY
		x.[sessions],
		DATEDIFF(MINUTE, s.last_request_end_time, GETDATE()),
		s.session_id,
        DB_NAME(s.database_id),
		s.[host_name],
        s.host_process_id,
        t.[text],
        s.[program_name]
	ORDER BY 1 DESC;

END;   