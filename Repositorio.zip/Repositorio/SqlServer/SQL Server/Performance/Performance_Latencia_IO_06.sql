USE master
GO
;WITH CTE AS
(
	SELECT  
		DB_NAME(vfs.database_id) AS [database_name],
		physical_name AS [physical_name],
        (size_on_disk_bytes / 1024 / 1024.) AS [size_of_disk],
        CAST(io_stall_read_ms/(1.0 + num_of_reads) AS NUMERIC(10,1)) AS [average_read_latency],
        CAST(io_stall_write_ms/(1.0 + num_of_writes) AS NUMERIC(10,1)) AS [average_write_latency],
        CAST((io_stall_read_ms + io_stall_write_ms) / (1.0 + num_of_reads + num_of_writes) AS NUMERIC(10,1)) AS [average_total_latency],
        (num_of_bytes_read / NULLIF(num_of_reads, 0)) AS [average_bytes_per_read],
        (num_of_bytes_written / NULLIF(num_of_writes, 0)) AS [average_bytes_per_write]
	FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs
		JOIN sys.master_files AS mf 
			ON vfs.database_id = mf.database_id 
				AND vfs.[file_id] = mf.[file_id]
)
SELECT *
FROM CTE
WHERE [average_total_latency] > 10.0
ORDER BY [average_total_latency] DESC;