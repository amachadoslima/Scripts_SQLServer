EXEC sp_BlitzCache 
	@SortOrder = 'cpu',
	@ExpertMode = 1,
	@Top = 5