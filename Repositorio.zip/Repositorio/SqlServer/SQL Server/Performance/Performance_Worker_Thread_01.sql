SELECT 
	AVG(current_tasks_count) AS [Avg Current Task],
	AVG(runnable_tasks_count) AS [Avg Wait Task]
FROM sys.dm_os_schedulers
WHERE scheduler_id < 255
	AND [status] = 'VISIBLE ONLINE'
GO

SELECT 
	*
FROM sys.dm_os_schedulers
WHERE scheduler_id < 255
	AND [status] = 'VISIBLE ONLINE'
	AND current_tasks_count > 0
GO

SELECT 
	*
FROM sys.dm_os_schedulers
WHERE scheduler_id < 255
	AND [status] = 'VISIBLE ONLINE'
	AND runnable_tasks_count > 0

SELECT
    s.cpu_id,
    s.[status],
    db_name(r.database_id) as [databaseName],
    w.last_wait_type, 
    w.return_code,
    t.task_state,
    t.pending_io_count,
    t.session_id,
    r.[sql_handle],
    te.[text]
FROM sys.dm_os_Schedulers s 
	JOIN sys.dm_os_workers w 
		ON w.scheduler_address = s.scheduler_address
	JOIN sys.dm_os_tasks t 
		ON t.task_address = w.task_address
	JOIN sys.dm_exec_requests r 
		ON r.scheduler_id = s.scheduler_id
	CROSS APPLY sys.dm_exec_sql_text(r.[sql_handle]) te
WHERE w.scheduler_address IN
	(
		SELECT 
			scheduler_address
		FROM sys.dm_os_schedulers
		WHERE scheduler_id < 255
			AND [status] = 'VISIBLE ONLINE'
			AND runnable_tasks_count > 0
	)
	AND t.session_id > 50
ORDER BY 1,3