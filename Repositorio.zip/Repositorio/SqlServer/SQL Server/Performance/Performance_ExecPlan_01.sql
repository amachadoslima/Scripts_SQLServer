USE master
GO
IF(OBJECTPROPERTY(OBJECT_ID('sp_check_plan_cache'), 'IsProcedure') = 1)
	DROP PROCEDURE sp_check_plan_cache
GO
CREATE PROCEDURE sp_check_plan_cache
(
	@Percent	decimal(6,3) OUTPUT,
	@WastedMB	decimal(19,3) OUTPUT
)
AS
BEGIN

	SET NOCOUNT ON


	DECLARE @ConfiguredMemory	decimal(19,3)
	DECLARE @PhysicalMemory		decimal(19,3)
	DECLARE @MemoryInUse		decimal(19,3)
	DECLARE @SingleUsePlanCount	bigint


	CREATE TABLE #ConfigurationOptions
	(
		[name]			nvarchar(35),
		[minimum]		int,
		[maximum]		int,
		[config_value]	int,				-- in bytes
		[run_value]		int,				-- in bytes
	);


	INSERT #ConfigurationOptions EXEC ('sp_configure ''max server memory''');
	
	SELECT 
		@ConfiguredMemory = run_value
	FROM #ConfigurationOptions
	WHERE name = 'max server memory (MB)'


	SELECT 
		@PhysicalMemory = total_physical_memory_kb/1024
	FROM sys.dm_os_sys_memory
	
	SELECT 
		@MemoryInUse = physical_memory_in_use_kb/1024
	FROM sys.dm_os_process_memory

	SELECT 
		@WastedMB = SUM(CAST((
			CASE 
				WHEN usecounts = 1 AND objtype IN ('Adhoc', 'Prepared') THEN size_in_bytes 
				ELSE 0 
			END) AS DECIMAL(12,2)))/1024/1024,
		@SingleUsePlanCount = SUM(
			CASE 
				WHEN usecounts = 1 AND objtype IN ('Adhoc', 'Prepared') THEN 1 
				ELSE 0 
		END),
		@Percent = @WastedMB/@MemoryInUse * 100
	FROM sys.dm_exec_cached_plans


	SELECT	
		[TotalPhysicalMemory (MB)] = @PhysicalMemory,
		[TotalConfiguredMemory (MB)] = @ConfiguredMemory,
		[MaxMemoryAvailableToSQLServer (%)] = @ConfiguredMemory/@PhysicalMemory * 100,
		[MemoryInUseBySQLServer (MB)] = @MemoryInUse,
		[TotalSingleUsePlanCache (MB)] = @WastedMB,
		TotalNumberOfSingleUsePlans = @SingleUsePlanCount,
		[PercentOfConfiguredCacheWastedForSingleUsePlans (%)] = @Percent
END
GO

DECLARE @Percent		decimal(6, 3)
DECLARE @WastedMB		decimal(19,3)
DECLARE @StrMB		nvarchar(20)
DECLARE @StrPercent	nvarchar(20)

EXEC sp_check_plan_cache 
	@Percent OUTPUT, 
	@WastedMB OUTPUT


SELECT 
	@StrMB = CONVERT(NVARCHAR(20), @WastedMB),
	@StrPercent = CONVERT(NVARCHAR(20), @Percent)


If(@Percent > 10 OR @WastedMB > 10)
Begin
		--DBCC FREESYSTEMCACHE('SQL Plans')
		RAISERROR ('%s MB (%s percent) was allocated to single-use plan cache. Single-use plans have been cleared.', 10, 1, @StrMB, @StrPercent)
End
Else
Begin
		RAISERROR ('Only %s MB (%s percent) is allocated to single-use plan cache - no need to clear cache now.', 10, 1, @StrMB, @StrPercent)
End
GO
