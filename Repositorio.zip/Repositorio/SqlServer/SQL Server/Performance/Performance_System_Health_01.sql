USE master
GO
BEGIN

	IF(OBJECT_ID(N'tempdb..#ServerDiagnostics') IS NOT NULL)
		DROP TABLE #ServerDiagnostics

	CREATE TABLE #ServerDiagnostics
	(
		  create_time		DATETIME,  
		  component_type	SYSNAME,  
		  component_name	SYSNAME,  
		  [state]			INT,  
		  state_desc		SYSNAME,  
		  [data]			XML
	)
 
	INSERT INTO #ServerDiagnostics
		EXEC sp_server_diagnostics 
 
	SELECT * 
	FROM #ServerDiagnostics 
 
	IF(OBJECT_ID(N'tempdb..#ServerDiagnostics') IS NOT NULL)
		DROP TABLE #ServerDiagnostics

END