SELECT
	[type] AS 'Plan Cach Store',
	buckets_count
FROM sys.dm_os_memory_cache_hash_tables
WHERE [type] IN('CACHESTORE_OBJCP', 'CACHESTORE_SQLCP');

SELECT
	[type],
	COUNT(1) AS 'Total Entries'
FROM sys.dm_os_memory_cache_entries
WHERE [type] IN('CACHESTORE_OBJCP', 'CACHESTORE_SQLCP')
GROUP BY [type];

SELECT   
	[type],
	memory_node_id,
    pages_kb,
    virtual_memory_reserved_kb,
    virtual_memory_committed_kb,
    awe_allocated_kb
FROM sys.dm_os_memory_clerks
ORDER BY virtual_memory_reserved_kb DESC;

SELECT   
	[name],
    [type],
    pages_kb,
	entries_count
FROM sys.dm_os_memory_cache_counters
ORDER BY pages_kb DESC;

SELECT   
	(COUNT(*) * 8 / 1024) AS 'Cached Size (MB)',
	CASE database_id
         WHEN 32767 THEN 'ResourceDb'
         ELSE DB_NAME(database_id)
	END AS 'Database'
FROM sys.dm_os_buffer_descriptors
GROUP BY db_name(database_id),database_id
ORDER BY 1 DESC;