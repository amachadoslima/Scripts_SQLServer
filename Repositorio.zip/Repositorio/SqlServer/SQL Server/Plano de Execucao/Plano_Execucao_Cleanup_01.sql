SET NOCOUNT ON

IF(OBJECT_ID(N'tempdb..#TEMP_CLEAN') IS NOT NULL)
	DROP TABLE #TEMP_CLEAN

DECLARE @MB decimal(19,3)
DECLARE @Count bigint
DECLARE @StrMB nvarchar(20)
DECLARE @Clean BIT = 0

SELECT 
	@MB = sum(cast((CASE WHEN usecounts = 1 AND objtype IN ('Adhoc', 'Prepared') THEN size_in_bytes ELSE 0 END) as decimal(12,2)))/1024/1024,
	@Count = sum(CASE WHEN usecounts = 1 AND objtype IN ('Adhoc', 'Prepared') THEN 1 ELSE 0 END),
	@StrMB = convert(nvarchar(20), @MB)
FROM sys.dm_exec_cached_plans

If(@MB > 10)
Begin
	RAISERROR ('%s MB was allocated to single-use plan cache. Single-use plans have been cleared.', 10, 1, @StrMB)
	
	Set @Clean = 1
	SELECT 
		ID = IDENTITY(INT, 1, 1),
		*, 
		'DBCC FREEPROCCACHE (' + master.dbo.fn_varbintohexstr(plan_handle) + ');' AS CMD_CLEAN
	INTO #TEMP_CLEAN
	FROM sys.dm_exec_cached_plans	
	WHERE usecounts = 1 AND objtype IN ('Adhoc', 'Prepared')
		AND (size_in_bytes /1024/1024) >= 1
End
Else
Begin
	RAISERROR ('Only %s MB is allocated to single-use plan cache � no need to clear cache now.', 10, 1, @StrMB)
End

---------------------------------------------------------------

DECLARE @ID INT
DECLARE @Cmd VARCHAR(1000)

If(@Clean = 1)
Begin

	While(Exists(SELECT 1 FROM #TEMP_CLEAN))
	Begin

		SELECT TOP 1
			@ID = ID,
			@Cmd = CMD_CLEAN
		FROM #TEMP_CLEAN

		--RAISERROR('> Comando executado... %s', 0, 1, @Cmd) WITH NOWAIT;
		EXEC (@Cmd)

		DELETE FROM #TEMP_CLEAN WHERE ID = @ID

	End

End