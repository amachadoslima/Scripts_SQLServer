select crdate as dahora_start
	from sys.sysdatabases 
	where [dbid] = 2