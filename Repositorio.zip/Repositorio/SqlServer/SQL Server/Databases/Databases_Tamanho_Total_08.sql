USE master
GO

BEGIN

	SELECT
		DB_Name(db.database_id) AS [database_name],
		((Cast(r.row_size as float) * 8) / 1024) AS row_size_mb,
		((Cast(r.row_size as float) * 8) / 1024 / 1024) AS row_size_gb,
		((Cast(l.log_size  as float) * 8) / 1024) as log_size_mb,
		((Cast(l.log_size  as float) * 8) / 1024 / 1024) as log_size_gb,
		((Cast(s.stream_size as float) * 8) / 1024) stream_size_mb,
		((Cast(t.text_index_size as float) * 8) / 1024) text_index_size_mb
	FROM sys.databases db
		LEFT JOIN (SELECT database_id, Sum(size) row_size FROM sys.master_files WHERE [type] = 0 GROUP BY database_id, [type]) r ON r.database_id = db.database_id
		LEFT JOIN (SELECT database_id, Sum(size) log_size FROM sys.master_files WHERE [type] = 1 GROUP BY database_id, [type]) l ON l.database_id = db.database_id
		LEFT JOIN (SELECT database_id, Sum(size) stream_size FROM sys.master_files WHERE [type] = 2 GROUP BY database_id, [type]) s ON s.database_id = db.database_id
		LEFT JOIN (SELECT database_id, Sum(size) text_index_size FROM sys.master_files WHERE [type] = 4 GROUP BY database_id, [type]) t ON t.database_id = db.database_id

END