use master 
go
begin

	select      
		db.[name] as [db_name],
		convert(varchar, sum(size) * 8 / 1024) as size_mb,
		convert(varchar, sum(size) * 8 / 1024 / 1024) as size_gb
	from sys.databases as db
		join sys.master_files as mf
			on db.database_id = mf.database_id
	group by db.[name]
	order by db.[name]

end