use master 
begin

	-- insira o valor do trace a ser analisado!
	declare @traceid int = 5

	-- Configura��es b�sicas do trace:
	select	
			case when max_size is null then '20' else convert(varchar, max_size) end as maxfilesize,
			case when max_files is null then ' 5 ' else convert(varchar, max_files) end as maxrolloverfiles,
			case when stop_time is null then null else convert(varchar(40), stop_time, 121) end as stoptime,
			case when [path] is null then 'n/a' else left([path], len([path]) - 4) end as [path]
		from sys.traces 
		where id = @traceid

	-- todos os eventos configurados:
	select
			 i.eventid as [eventid],
			 i.columnid as [columnid],
			 e.[name] + ', ' + c.[name] as descricao
		from ::fn_trace_geteventinfo(@traceid) as i
			join sys.trace_events e on i.eventid  = e.trace_event_id
			join sys.trace_columns c on i.columnid = c.trace_column_id
	
	-- Filtros configurados:
	select 
			c.[name],
			--logical_operator as [logicaloperator],
			--comparison_operator as [comparisonoperator],
			convert(varchar(8000), [value]) + case when logical_operator = 0 then ' AND ' else ' OR ' end + c.[name] +
				case 
					when comparison_operator = 0  then ' = '
					when comparison_operator = 1  then ' <> '
					when comparison_operator = 2  then ' > '
					when comparison_operator = 3  then ' < '
					when comparison_operator = 4  then ' >= '
					when comparison_operator = 5  then ' <= '
					when comparison_operator = 6  then ' LIKE '
					when comparison_operator = 7  then ' NOT LIKE '
				end + convert(varchar(8000), [value]) as [filter]
		from ::fn_trace_getfilterinfo(@traceid) f
			join sys.trace_columns c on f.columnid = c.trace_column_id
end