use master 
go
begin
	
	----Auto Stats, Indicates an automatic updating of index statistics has occurred.

	set nocount on
	set quoted_identifier off

	if(object_id(N'tempdb..##tmptraces') is not null)
		drop table ##tmptraces

	declare @id int 
	declare @file varchar(1000)
	declare @folder varchar(300)
	declare @cmd varchar(400)
	declare @sql varchar(max)

	declare @arquivos table
	(
		subdirectory varchar(4000),
		depth smallint,
		[file] smallint
	)

	select top 1 @id = id
		from sys.traces
		
	select @file = cast(value as varchar(300))
		from ::fn_trace_getinfo(@id)
		where property = 2
		
	select top (0) 
		textdata,
		[databasename],
		objectid, 
		objectname, 
		indexid
		duration,
		starttime,
		endtime,
		spid,
		applicationname,
		loginname,
		reads,
		writes,
		cpu  
	into ##tmptraces
	from ::fn_trace_gettable(@file, default) 
		
	if(@@version like '%Linux%')
		set @folder = reverse(right(reverse(@file), len(@file) - charindex('/', reverse(@file))))
	else
		set @folder = reverse(right(reverse(@file), len(@file) - charindex('\', reverse(@file))))
	
	insert into @arquivos
		exec master.sys.xp_dirtree @folder , 1, 1

	--set @cmd = 'dir "' + @folder + '" /b | find /i "trc"'

	--insert into @arquivos
	--	exec xp_cmdshell @cmd
	delete from @arquivos where subdirectory is null
	delete from @arquivos where subdirectory not like '%.trc'

	if(@@version like '%Linux%')
		update @arquivos 
		set subdirectory = @folder + '/' + subdirectory
	else
		update @arquivos 
		set subdirectory = @folder + '\' + subdirectory

	declare cur cursor for
		select subdirectory 
			from @arquivos
			
	open cur
	fetch next from cur into @file 

	while(@@fetch_status = 0)
	begin

		set @sql ='
		insert into ##tmptraces
			select 
				textdata,
				[databasename],
				objectid, 
				objectname, 
				indexid
				duration,
				starttime,
				endtime,
				spid,
				applicationname,
				loginname,
				reads,
				writes,
				cpu  
			from sys.fn_trace_gettable(''' + @file + ''', default)
			where eventclass in (58)
			order by starttime desc
		'

		print (@sql)
		exec (@sql)

		fetch next from cur into @file 
	end

	close cur
	deallocate cur

	select * 
	from ##tmptraces
	--where errorname like '%erro%'
	order by starttime desc

	if(object_id(N'tempdb..##tmptraces') is not null)
		drop table ##tmptraces
		
end