use master 
go
begin

	--Security Audit: Audit DBCC CHECKDB, DBCC CHECKTABLE, DBCC CHECKCATALOG,
	--DBCC CHECKALLOC, DBCC CHECKFILEGROUP Events, and more.
/*SELECT 
	TextData, 
	Duration, 
	StartTime, 
	EndTime, 
	SPID, 
	ApplicationName, 
	LoginName  
FROM sys.fn_trace_gettable(@path, DEFAULT)
WHERE EventClass IN (116) 
	AND TextData LIKE '%DBCC%CHECK%'
ORDER BY StartTime DESC*/

	set nocount on
	set quoted_identifier off

	if(object_id(N'tempdb..##tmptraces') is not null)
		drop table ##tmptraces

	declare @id int 
	declare @file varchar(1000)
	declare @folder varchar(300)
	declare @cmd varchar(400)
	declare @sql varchar(max)

	declare @arquivos table
	(
		subdirectory varchar(4000),
		depth smallint,
		[file] smallint
	)

	select top 1 @id = id
		from sys.traces
		
	select @file = cast(value as varchar(300))
		from ::fn_trace_getinfo(@id)
		where property = 2
		
	select top (0) 
		textdata, 
		duration, 
		starttime, 
		endtime, 
		spid, 
		applicationname, 
		loginname  
	into ##tmptraces
	from ::fn_trace_gettable(@file, default) 
	where eventclass in (116) 
		and textdata like '%DBCC%CHECK%'
		
	if(@@version like '%Linux%')
		set @folder = reverse(right(reverse(@file), len(@file) - charindex('/', reverse(@file))))
	else
		set @folder = reverse(right(reverse(@file), len(@file) - charindex('\', reverse(@file))))
	
	insert into @arquivos
		exec master.sys.xp_dirtree @folder , 1, 1

	--set @cmd = 'dir "' + @folder + '" /b | find /i "trc"'

	--insert into @arquivos
	--	exec xp_cmdshell @cmd
	delete from @arquivos where subdirectory is null
	delete from @arquivos where subdirectory not like '%.trc'

	if(@@version like '%Linux%')
		update @arquivos 
		set subdirectory = @folder + '/' + subdirectory
	else
		update @arquivos 
		set subdirectory = @folder + '\' + subdirectory

	declare cur cursor for
		select subdirectory 
			from @arquivos
			
	open cur
	fetch next from cur into @file 

	while(@@fetch_status = 0)
	begin

		set @sql ='
		insert into ##tmptraces
			select 
				textdata, 
				duration, 
				starttime, 
				endtime, 
				spid, 
				applicationname, 
				loginname 
			from sys.fn_trace_gettable(''' + @file + ''', default)
			where eventclass in (116) 
				and textdata like ''%DBCC%CHECK%''
		'

		print (@sql)
		exec (@sql)

		fetch next from cur into @file 
	end

	close cur
	deallocate cur

	select * 
	from ##tmptraces
	--where errorname like '%erro%'
	order by starttime desc

	if(object_id(N'tempdb..##tmptraces') is not null)
		drop table ##tmptraces
		
end