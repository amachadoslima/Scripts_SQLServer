use master 
go
begin
	
	set nocount on
	set quoted_identifier off

	if(object_id(N'tempdb..##tmpGrowth') is not null)
		drop table ##tmpGrowth

	declare @id int 
	declare @file varchar(1000)
	declare @folder varchar(300)
	declare @cmd varchar(400)
	declare @sql varchar(max)

	declare @arquivos table
	(
		subdirectory varchar(4000),
		depth smallint,
		[file] smallint
	)

	select top 1 @id = id
		from sys.traces
		
	select @file = cast(value as varchar(300))
		from ::fn_trace_getinfo(@id)
		where property = 2
		
	create table ##tmpGrowth
	(
		event_name nvarchar(256),
		spid int,
		[database_name] nvarchar(256),
		[file_name]	nvarchar(512),
		growth_mb numeric(17, 6),
		server_name sysname,
		start_time_utc datetime,
		start_time_local as dateadd(hour, -3, start_time_utc),
		end_time_utc datetime,
		end_time_local as dateadd(hour, -3, end_time_utc),
		dur_ms bigint, 
		application_name nvarchar(512),
		login_name nvarchar(512),
		text_data varchar(max)
	)
	
	if(@@version like '%Linux%')
		set @folder = reverse(right(reverse(@file), len(@file) - charindex('/', reverse(@file))))
	else
		set @folder = reverse(right(reverse(@file), len(@file) - charindex('\', reverse(@file))))
	
	insert into @arquivos
		exec master.sys.xp_dirtree @folder, 1, 1

	delete from @arquivos where subdirectory is null
	delete from @arquivos where subdirectory not like '%.trc%'
	
	if(@@version like '%Linux%')
		update @arquivos 
		set subdirectory = @folder + '/' + subdirectory
	else
		update @arquivos 
		set subdirectory = @folder + '\' + subdirectory

	declare cur cursor for
		select subdirectory 
			from @arquivos
			
	open cur
	fetch next from cur into @file 

	while(@@fetch_status = 0)
	begin

		set @sql ='
		insert into ##tmpGrowth
		(
			event_name,
			spid,
			[database_name],
			[file_name],
			growth_mb,		
			server_name,
			start_time_utc,
			end_time_utc,
			dur_ms, 			
			application_name,
			login_name,
			text_data
		)
		select
				te.[name] as event_name,
				ftg.spid,
				db_name(ftg.DatabaseID) as [database_name],
				ftg.[FileName],
				(ftg.IntegerData * 8) / 1024.0 as [growth_mb],
				ftg.ServerName,
				ftg.StartTime,
				ftg.EndTime,
				(ftg.Duration / 1000) as durms,
				ftg.ApplicationName,
				ftg.LoginName,
				ftg.TextData 
			from ::fn_trace_gettable(''' + @file + ''', default) as ftg 
				join sys.trace_events as te on ftg.EventClass = te.trace_event_id
			where (te.trace_event_id = 92  -- date file auto-grow
				or te.trace_event_id = 93) -- log file auto-grow
			order by ftg.StartTime desc
		'
		
		print (@sql)
		exec (@sql)

		fetch next from cur into @file 
	end

	close cur
	deallocate cur

	select distinct * 
		from ##tmpGrowth
		order by start_time_utc desc

	if(object_id(N'tempdb..##tmpGrowth') is not null)
		drop table ##tmpGrowth
		
end