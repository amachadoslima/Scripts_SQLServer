use master 
go
begin
	
	set nocount on
	set quoted_identifier off

	if(object_id(N'tempdb..##tmptraces') is not null)
		drop table ##tmptraces

	declare @id int 
	declare @file varchar(1000)
	declare @folder varchar(300)
	declare @cmd varchar(400)
	declare @sql varchar(max)

	declare @arquivos table
	(
		subdirectory varchar(4000),
		depth smallint,
		[file] smallint
	)

	select top 1 @id = id
		from sys.traces
		
	select @file = cast(value as varchar(300))
		from ::fn_trace_getinfo(@id)
		where property = 2
		
	select top (0) *
		into ##tmptraces
		from ::fn_trace_gettable(@file, default) 
		
		
	alter table ##tmptraces add CategoryID int
	alter table ##tmptraces add ErrorName varchar(300)
	alter table ##tmptraces add CategoryName varchar(300)
	
	if(@@version like '%Linux%')
		set @folder = reverse(right(reverse(@file), len(@file) - charindex('/', reverse(@file))))
	else
		set @folder = reverse(right(reverse(@file), len(@file) - charindex('\', reverse(@file))))
	
	insert into @arquivos
		exec master.sys.xp_dirtree @file, 1, 1

	--set @cmd = 'dir "' + @folder + '" /b | find /i "trc"'

	--insert into @arquivos
	--	exec xp_cmdshell @cmd
		
	delete from @arquivos where subdirectory is null
	delete from @arquivos where subdirectory not like '%.trc%'

	if(@@version like '%Linux%')
		update @arquivos 
		set subdirectory = @folder + '/' + subdirectory
	else
		update @arquivos 
		set subdirectory = @folder + '\' + subdirectory

	declare cur cursor for
		select subdirectory 
			from @arquivos
			
	open cur
	fetch next from cur into @file 

	while(@@fetch_status = 0)
	begin

		set @sql ='
			insert into ##tmptraces
			select a.*, b.category_id, b.[name], c.[name]
				from ::fn_trace_gettable(''' + @file + ''', default) a
					join sys.trace_events b on b.trace_event_id = a.eventclass 
					join sys.trace_categories c on b.category_id = c.category_id
				where c.category_id in(3, 4)
				order by starttime asc
		'
		
		print (@sql)
		exec (@sql)

		fetch next from cur into @file 
	end

	close cur
	deallocate cur

	select * 
	from ##tmptraces
	--where errorname like '%erro%'
	order by StartTime desc

	if(object_id(N'tempdb..##tmptraces') is not null)
		drop table ##tmptraces
		
end