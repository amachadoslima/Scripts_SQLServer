use master 
go
-- audit log
select
		te.[name] as [event_name],
		v.subclass_name,
		t.databasename as [database_name],
		t.databaseid as [database_id],
		t.ntdomainname as nt_domain_name,
		t.applicationname as application_name,
		t.loginname as login_name,
		t.spid,
		t.starttime as start_time,
		t.rolename as role_name,
		/*t.spid,*/
		t.targetusername as target_user_name,
		t.targetloginname as target_login_name,
		t.sessionloginname as session_login_name
	from sys.fn_trace_gettable(convert(varchar(150),
		(
			select top 1 [value]
			from sys.fn_trace_getinfo(null) f
			where property = 2
		)), default) t
		join sys.trace_events te on t.eventclass = te.trace_event_id
		join sys.trace_subclass_values v on v.trace_event_id = te.trace_event_id and v.subclass_value = t.eventsubclass
	where lower(te.[name]) in('audit server starts and stops')