SELECT 
	ot.session_id,
	CONVERT(varchar(10), ex.status) AS status_req,
	CONVERT(varchar(15), ex.command) AS command,  
	ow.pending_io_count,
	CASE ow.wait_started_ms_ticks
		WHEN 0 THEN 0
		ELSE (osi.ms_ticks - ow.wait_started_ms_ticks)/1000 
	END AS Suspended_wait,
	CASE ow.wait_resumed_ms_ticks
		WHEN 0 THEN 0
		ELSE (osi.ms_ticks - ow.wait_resumed_ms_ticks)/1000 
	END AS Runnable_wait,
	(osi.ms_ticks - ow.task_bound_ms_ticks)/1000 AS task_time,
	(osi.ms_ticks - ow.worker_created_ms_ticks)/1000 AS worker_time,
	ow.end_quantum - ow.start_quantum AS last_worker_quantum,
	ow.state,
	ow.last_wait_type,
	ow.affinity,
	ow.quantum_used,
	ow.tasks_processed_count
FROM sys.dm_os_workers ow
	JOIN sys.dm_os_tasks ot
		ON ow.task_address = ot.task_address
	JOIN sys.dm_exec_requests ex
		ON ex.task_address = ow.task_address
	CROSS JOIN sys.dm_os_sys_info osi
WHERE ot.session_id > 50
	AND is_preemptive = 0

GO

SELECT 
	text, 
	query_plan, 
	requested_memory_kb,
	granted_memory_kb,
	used_memory_kb, 
	wait_order
FROM sys.dm_exec_query_memory_grants MG
CROSS APPLY sys.dm_exec_sql_text(sql_handle)
CROSS APPLY sys.dm_exec_query_plan(MG.plan_handle)