DECLARE @hyperthreadingRatio BIT
DECLARE @logicalCPUs INT
DECLARE @HTEnabled INT
DECLARE @physicalCPU INT
DECLARE @SOCKET INT
DECLARE @logicalCPUPerNuma INT
DECLARE @NoOfNUMA INT

SELECT 
	@logicalCPUs = cpu_count, -- [Logical CPU Count]
    @hyperthreadingRatio = hyperthread_ratio, --  [Hyperthread Ratio]
    @physicalCPU = cpu_count / hyperthread_ratio, -- [Physical CPU Count]
    @HTEnabled = 
		CASE 
			WHEN cpu_count > hyperthread_ratio THEN 1
			ELSE 0
		END -- HTEnabled
FROM sys.dm_os_sys_info
OPTION (RECOMPILE);

SELECT 
	@logicalCPUPerNuma = COUNT(parent_node_id) -- [NumberOfLogicalProcessorsPerNuma]
FROM sys.dm_os_schedulers
WHERE [status] = 'VISIBLE ONLINE'
    AND parent_node_id < 64
GROUP BY parent_node_id
OPTION (RECOMPILE);

SELECT 
	@NoOfNUMA = COUNT(DISTINCT parent_node_id)
FROM sys.dm_os_schedulers -- find NO OF NUMA Nodes 
WHERE [status] = 'VISIBLE ONLINE'
    AND parent_node_id < 64

SELECT
	--- 8 or less processors and NO HT enabled
	CASE 
		WHEN @logicalCPUs < 8 AND @HTEnabled = 0 THEN 'MAXDOP setting should be : ' + CAST(@logicalCPUs as varchar(3))
				--- 8 or more processors and NO HT enabled
		WHEN @logicalCPUs >= 8 AND @HTEnabled = 0 THEN 'MAXDOP setting should be : 8'
				--- 8 or more processors and HT enabled and NO NUMA
		WHEN @logicalCPUs >= 8 AND @HTEnabled = 1 AND @NoofNUMA = 1 THEN 'MaxDop setting should be : ' + CAST(@logicalCPUPerNuma / @physicalCPU as varchar(3))
				--- 8 or more processors and HT enabled and NUMA
		WHEN @logicalCPUs >= 8 AND @HTEnabled = 1 AND @NoofNUMA > 1 THEN 'MaxDop setting should be : ' + CAST(@logicalCPUPerNuma / @physicalCPU as varchar(3))
		ELSE ''
	END AS Recommendations