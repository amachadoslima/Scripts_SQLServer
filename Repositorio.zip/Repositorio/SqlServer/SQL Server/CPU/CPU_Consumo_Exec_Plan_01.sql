USE master
GO

DECLARE @MaxDop INT
SELECT @MaxDop = CONVERT(INT, [value_in_use]) FROM sys.configurations WHERE [name] = 'max degree of parallelism'

SELECT TOP(10)
	db_name(t.[dbid]),
	qs.execution_count AS [Execution Count],
	DateAdd(Hour, -3, qs.last_execution_time) as last_execution_time,
	t.[text] AS [Query Text],
	(qs.total_logical_reads + qs.total_logical_writes) /qs.execution_count as [Avg IO],
	qs.[last_grant_kb],
	qs.[last_ideal_grant_kb],
	qs.[last_used_grant_kb],
	qs.[total_grant_kb],
	qs.[total_dop],
	qs.[total_dop]/qs.execution_count as avg_dop,
	qs.[last_dop],
	(CASE WHEN qs.[last_dop] > @MaxDop THEN 'ATEN��O' ELSE 'OK' END) AS [status_last_dop],
	qs.[min_dop],
	qs.[max_dop],
	(CASE WHEN qs.[max_dop] > @MaxDop THEN 'ATEN��O' ELSE 'OK' END) AS [status_max_dop],
	qs.[last_used_threads],
	qs.total_used_threads,
	qs.last_used_threads,
	min_used_threads,
	max_used_threads,
	qp.query_plan,
	plan_handle
FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
	CROSS APPLY	sys.dm_exec_sql_text(plan_handle) AS t
	CROSS APPLY sys.dm_exec_query_plan(plan_handle) as qp
WHERE qs.[total_grant_kb] > 0
	--AND t.[text] LIKE '%SELECT this_.Id AS y0_,%'
--ORDER BY avg_dop DESC
--ORDER BY last_execution_time DESC
ORDER BY [last_dop] DESC