SELECT
	R.session_id,
	R.database_id,
	R.command, 
	R.start_time,
	CONVERT(INT, R.percent_complete) AS percente_complete,
	SUBSTRING(ST.[text], R.statement_start_offset / 2, 
		CASE 
			WHEN R.statement_end_offset = -1 THEN 1000 
			ELSE (R.statement_end_offset - R.statement_start_offset) / 2 
		END) AS sqlstatement
FROM (SELECT @@SERVERNAME AS [server]) S
	LEFT JOIN sys.dm_exec_requests R ON LOWER(R.command) LIKE '%backup%'
	OUTER APPLY sys.dm_exec_sql_text(R.[sql_handle]) ST
WHERE ST.[text] NOT LIKE '%COPY_ONLY%'