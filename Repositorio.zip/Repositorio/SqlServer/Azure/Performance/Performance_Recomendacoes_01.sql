go
WITH CTE AS
(
SELECT 
	reason, 
	score, 
	DATEADD(HOUR, -3, last_refresh) AS last_refresh,
    query_id,
    regressed_plan_id,
    recommended_plan_id,
    current_state = JSON_VALUE([state], '$.currentValue'),
    current_state_reason = JSON_VALUE([state], '$.reason'),
    script = JSON_VALUE(details, '$.implementationDetails.script'),
    estimated_gain = ((regressed_plan_execution_count + recommended_plan_execution_count) * (regressed_plancpu_time_average - recommended_plan_cpu_time_average) / 1000000),
	error_prone = IIF(regressed_plan_error_count > recommended_plan_error_count, 'yes','no')
FROM sys.dm_db_tuning_recommendations
	CROSS APPLY OPENJSON(details, '$.planForceDetails') 
	WITH (
		query_id INT '$.queryId',
		regressed_plan_id INT '$.regressedPlanId',
		recommended_plan_id INT '$.recommendedPlanId',
		regressed_plan_error_count INT,    
		recommended_plan_error_count INT,
		regressed_plan_execution_count INT,
		regressed_plancpu_time_average FLOAT,
		recommended_plan_execution_count INT,
		recommended_plan_cpu_time_average FLOAT
	)
)
SELECT 
	QSQ.query_id, 
	QSQT.query_sql_text, 
	DTR.*, 
	CAST(RP.query_plan AS XML) AS regressedplan, 
	CAST(SP.query_plan AS XML) AS suggestedplan
FROM CTE AS DTR
	JOIN sys.query_store_plan AS RP 
		ON RP.query_id = dtr.query_id 
			AND RP.plan_id = dtr.regressed_plan_id
	JOIN sys.query_store_plan AS SP 
		ON SP.query_id = dtr.query_id 
			AND SP.plan_id = dtr.recommended_plan_id
	JOIN sys.query_store_query AS QSQ 
		ON QSQ.query_id = RP.query_id
	JOIN sys.query_store_query_text AS QSQT 
		ON QSQT.query_text_id = QSQ.query_text_id
ORDER BY last_refresh DESC