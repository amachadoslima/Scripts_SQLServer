IF(OBJECT_ID(N'tempdb..#ExecRequests') IS NOT NULL)
	DROP TABLE #ExecRequests;

CREATE TABLE #ExecRequests
(
	id						INT IDENTITY(1,1) PRIMARY KEY,
	session_id				SMALLINT NOT NULL,
	request_id				INT,
	blocking_these			VARCHAR(1000) NULL,
	start_time				datetime,
	[status]				NVARCHAR(60),
	command					NVARCHAR(32),
	[sql_handle]			VARBINARY(64),
	statement_start_offset	INT,
	statement_end_offset	INT,
	plan_handle				VARBINARY(64),
	databaseid				SMALLINT,
	[userid]				INT,
	blocking_session_id		SMALLINT,
	wait_type				NVARCHAR(120),
	wait_time				INT,
	cpu_time				INT,
	tot_time				INT,
	reads					BIGINT,
	writes					BIGINT,
	logical_reads			BIGINT,
	[host_name]				NVARCHAR(256),
	[program_name]			NVARCHAR(256)
)

INSERT INTO #EXECREQUESTS
(
	 session_id, blocking_session_id, request_id, start_time, [status], command, [sql_handle], statement_start_offset, statement_end_offset, plan_handle,
	 databaseid, userid, wait_type, wait_time, cpu_time, tot_time, reads, writes, logical_reads, [host_name], [program_name]
)
SELECT 
	R.session_id, 
	blocking_session_id, 
	request_id, start_time, 
	R.[status], 
	command, 
	[sql_handle], 
	statement_start_offset, 
	statement_end_offset, 
	plan_handle, 
	R.database_id, 
	[user_id], 
	wait_type, 
	wait_time, 
	R.cpu_time, 
	R.total_elapsed_time, 
	R.reads,
	R.writes, 
	R.logical_reads, 
	S.[host_name], 
	S.[program_name]
FROM sys.dm_exec_requests R WITH(NOLOCK)
	LEFT OUTER JOIN	sys.dm_exec_sessions S WITH(NOLOCK) ON R.session_id = S.session_id
WHERE  R.session_id > 50 -- apenas ids de usu�rios
	AND R.session_id <> @@spid -- ignora a sess�o que est� executando esta query
	AND R.[status] <> 'background'

UPDATE #ExecRequests 
SET	blocking_these = 
(
	SELECT 
		ISNULL(CONVERT(VARCHAR(5), ER.session_id), '') + ', '
	FROM #ExecRequests ER
	WHERE ER.blocking_session_id = ISNULL(#ExecRequests.session_id, 0)
		AND ER.blocking_session_id <> 0
	FOR XML PATH('')
)

SELECT * 
FROM #ExecRequests 
ORDER BY 
	blocking_session_id, 
	session_id;

IF(OBJECT_ID(N'tempdb..#ExecRequests') IS NOT NULL)
	DROP TABLE #ExecRequests