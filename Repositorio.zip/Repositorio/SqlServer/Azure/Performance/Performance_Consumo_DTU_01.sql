SELECT    
	AVG(AVG_cpu_percent) AS 'Average CPU Utilization in Percent',   
	MAX(AVG_cpu_percent) AS 'Maximum CPU Utilization in Percent',   
	AVG(AVG_data_io_percent) AS 'Average Data I/O in Percent',   
	MAX(AVG_data_io_percent) AS 'Maximum Data I/O in Percent',   
	AVG(AVG_log_write_percent) AS 'Average Log Write I/O Throughput Utilization in Percent',   
	MAX(AVG_log_write_percent) AS 'Maximum Log Write I/O Throughput Utilization in Percent',   
	AVG(AVG_memory_usage_percent) AS 'Average Memory Usage in Percent',
	MAX(AVG_memory_usage_percent) AS 'Maximum Memory Usage in Percent'
FROM sys.dm_db_resource_stats;