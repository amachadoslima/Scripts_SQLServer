DECLARE @Threshold INT = 1

SELECT
	@@SERVERNAME AS instancia,
	record_id,
	sql_process_utilization,
	system_idle,
	(100 - system_idle - sql_process_utilization) AS otherprocessutilization
FROM (
	SELECT	
		record.value('(./Record/@id)[1]', 'int') AS record_id,
		record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') AS system_idle,
		record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS sql_process_utilization,
		[timestamp]
	FROM (
		SELECT 
			[timestamp], 
			CONVERT(XML, record) AS record
		FROM sys.dm_os_ring_buffers
		WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
			AND record LIKE '%<SystemHealth>%'
	) AS X
) AS Y
WHERE sql_process_utilization >= @Threshold
ORDER BY record_id ASC