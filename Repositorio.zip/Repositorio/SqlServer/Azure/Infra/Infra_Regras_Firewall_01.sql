SELECT 
	id,
	[name],
	start_ip_address,
	end_ip_address,
	DATEADD(HOUR, -3, create_date) AS create_date,
	DATEADD(HOUR, -3, modify_date) As modify_date
FROM sys.firewall_rules  
ORDER BY id