SELECT TOP 500
	[database_name],
	DATEADD(HOUR, -3, start_time) AS start_time,
	DATEADD(HOUR, -3, end_time) AS end_time,
	event_category,
	event_type,
	event_subtype_desc,
	severity 
	event_count,
	[description],
	additional_data
FROM sys.event_log
ORDER BY DATEADD(HOUR, -3, end_time) DESC