SELECT	
	U.session_id,
	I.event_info as [sqltext],
	I.parameters,
	I.event_type,
	(U.user_objects_alloc_page_count / 128) AS user_objs_total_sizemb,
	((U.user_objects_alloc_page_count - U.user_objects_dealloc_page_count) / 128.0) AS user_objs_active_sizemb,
	(U.internal_objects_alloc_page_count / 128) AS internal_objs_total_sizemb,
	((U.internal_objects_alloc_page_count - internal_objects_dealloc_page_count) / 128.0) AS internal_objs_active_sizemb
FROM sys.dm_db_session_space_usage U
	OUTER APPLY sys.dm_exec_input_buffer(U.session_id, NULL) AS I
WHERE U.session_id <> @@SPID
	AND I.event_type <> 'No Event'
ORDER BY user_objects_alloc_page_count DESC