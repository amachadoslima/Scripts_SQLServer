SELECT 
	I.event_info AS [sqltext],
	I.parameters,
	I.event_type,
	T.task_address, 
	T.parent_task_address,
	TSU.session_id,
	TSU.request_id,
	T.exec_context_id,
	TSU.user_objects_alloc_page_count/128 AS total_usermb,
	((TSU.user_objects_alloc_page_count - TSU.user_objects_dealloc_page_count) / 128.0) AS acive_usermb,
	TSU.internal_objects_alloc_page_count/128 AS total_intmb,
	((TSU.internal_objects_alloc_page_count - TSU.internal_objects_dealloc_page_count) / 128.0) AS active_intmb,
	T.task_state,
	T.scheduler_id,
	T.worker_address
from sys.dm_db_task_space_usage TSU
	JOIN sys.dm_os_tasks T ON TSU.session_id = T.session_id 
		AND TSU.exec_context_id = T.exec_context_id
	OUTER APPLY sys.dm_exec_input_buffer(t.session_id, NULL) AS I
WHERE T.session_id <> @@SPID
ORDER BY 
	task_state, 
	TSU.session_id