SELECT 
	C.session_id, 
	S.[status], 
	S.[host_name],
	S.login_name, 
	DATEADD(HOUR, -3, C.connect_time) AS connect_time, 
	DATEADD(HOUR, -3, S.last_request_start_time) AS last_request_start_time, 
	I.event_info AS [sqltext],
	I.parameters,
	I.event_type,
	S.reads, 
	S.writes, 
	S.logical_reads, 
	S.row_count
FROM sys.dm_exec_connections AS C WITH(NOLOCK)
	JOIN sys.dm_exec_sessions AS S WITH(NOLOCK) 
		ON C.session_id = S.session_id
	--JOIN sys.dm_exec_requests AS R WITH(NOLOCK) 
	--	ON S.session_id = R.session_id
	OUTER APPLY sys.dm_exec_input_buffer(S.session_id, NULL) AS I
WHERE S.login_name <> 'NT AUTHORITY\SYSTEM' 
	AND S.session_id <> @@SPID 
	AND S.[status] <> 'dormant'
	AND [host_name] <> 'KMS-NB257'
ORDER BY 
	S.[status] ASC, 
	S.last_request_start_time DESC