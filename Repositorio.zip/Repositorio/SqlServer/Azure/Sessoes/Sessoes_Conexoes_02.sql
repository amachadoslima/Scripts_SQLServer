SELECT
	C.session_id, 
	C.net_transport, 
	C.encrypt_option,
	S.status,
	c.auth_scheme, 
	S.[host_name], 
	S.[program_name],
	S.client_interface_name, 
	S.login_name, 
	S.nt_domain,
	S.nt_user_name, 
	S.original_login_name, 
	C.connect_time,
	S.login_time
FROM sys.dm_exec_connections AS C
	JOIN sys.dm_exec_sessions AS S 
		ON C.session_id = S.session_id
ORDER BY C.connect_time ASC