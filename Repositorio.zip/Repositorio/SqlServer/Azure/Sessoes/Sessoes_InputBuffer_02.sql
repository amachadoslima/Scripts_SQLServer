SET NOCOUNT ON

DECLARE @OSQL TABLE
(
	SPID			INT,
	[Status]		VARCHAR(100),
	HostName		VARCHAR(100),
	IPAddrr			VARCHAR(100),
	--programname	VARCHAR(500),
	LoginName		VARCHAR(100),
	ConnectTime		DATETIME,
	LastRequest		DATETIME,
	SQLText			VARCHAR(MAX),
	Reads			INT,
	Writes			INT,
	LogicalReads	INT,
	[RowCount]		INT,
	--outputbuffer	VARCHAR(MAX),
	KillCmd			VARCHAR(MAX)
)
	
DECLARE @spid			VARCHAR(100)
DECLARE @hostname		VARCHAR(100)
DECLARE @programname	VARCHAR(500)
DECLARE @loginname		VARCHAR(100)
DECLARE @connecttime	DATETIME
DECLARE @lastrequest	DATETIME
DECLARE @status			VARCHAR(100)
DECLARE @reads			INT
DECLARE @writes			INT
DECLARE @logicalreads	INT
DECLARE @rowcount		INT
DECLARE @ipaddrr		VARCHAR(100)

BEGIN TRY

	DECLARE SPID CURSOR FOR 
		SELECT 
			C.session_id, 
			S.[host_name], 
			S.login_name, 
			DATEADD(HOUR, -3, C.connect_time), 
			DATEADD(HOUR, -3, S.last_request_start_time), 
			S.[status], 
			S.reads, 
			S.writes, 
			S.logical_reads, 
			S.row_count, 
			C.client_net_address
		from sys.dm_exec_connections AS C WITH(NOLOCK)
			JOIN sys.dm_exec_sessions AS S WITH(NOLOCK) 
				ON C.session_id = S.session_id

	OPEN SPID
	FETCH NEXT FROM SPID INTO @spid, @hostname, @loginname, @connecttime, @lastrequest, @status, @reads, @writes, @logicalreads, @rowcount, @ipaddrr

	WHILE(@@FETCH_STATUS = 0)
	BEGIN
		
		INSERT INTO @OSQL (spid, hostname, loginname, connecttime, lastrequest, [status], reads, writes, logicalreads, [rowcount], ipaddrr)
			SELECT @spid, @hostname, @loginname, @connecttime, @lastrequest, @status, @reads, @writes, @logicalreads, @rowcount, @ipaddrr
		
		DECLARE @AUX TABLE
		(
			eventtype NVARCHAR(MAX),
			parameters NVARCHAR(MAX),
			eventinfo NVARCHAR(MAX)
		)
		
		INSERT INTO @AUX
			EXEC ('DBCC INPUTBUFFER(' + @spid + ') WITH NO_INFOMSGS')
			
		UPDATE @OSQL
		SET sqltext = (SELECT RTRIM(LTRIM(REPLACE(eventinfo, (CHAR(13) + CHAR(10)), ''))) FROM @AUX),
			--outputbuffer = 'dbcc outputbuffer (' + @spid + ');',
			killcmd = 'kill ' + @spid + ';'
		WHERE spid = @spid

		DELETE FROM @AUX
		FETCH NEXT FROM SPID INTO @spid, @hostname, @loginname, @connecttime, @lastrequest, @status, @reads, @writes, @logicalreads, @rowcount, @ipaddrr

	END

	CLOSE SPID
	DEALLOCATE SPID


	SELECT * 
	FROM @OSQL 
	WHERE sqltext IS NOT NULL 
		AND loginname <> 'NT AUTHORITY\SYSTEM' 
		AND spid <> @@SPID 
		AND [status] <> 'dormant'
		AND [hostname] <> 'KMS-NB257'
	ORDER BY 
		[status], 
		spid

END TRY
BEGIN CATCH
	SELECT ERROR_LINE() AS ERR_LINE, ERROR_NUMBER() AS ERR_NUM, ERROR_MESSAGE() AS ERR_MSG
	CLOSE SPID
	DEALLOCATE SPID
END CATCH